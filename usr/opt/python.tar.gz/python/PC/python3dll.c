#include <windows.h>

BOOL WINAPI
DllMain(HINSTANCE hInstDLL,
        DWORD fdwReason,
        LPVOID lpReserved)
{
    return TRUE;
}